# Importing Pre made modules
import tkinter as tk
from tkinter import messagebox
from tkinter.ttk import *  
from PIL import Image, ImageTk

# Importing Project made modules
import colors
import fonts
import assets
from profile_form import profile_data


#### Constants : for the active control and other fixed parts
## Current page 



class Dashboard():

    def __init__(self) -> None:
        self.dashboard = tk.Tk()
        self.dashboard.overrideredirect(True)
        self.screen_height  = self.dashboard.winfo_screenheight()
        self.screen_width = self.dashboard.winfo_screenwidth()
        self.height  = 700
        self.width  = 1000
        self.ycoordinate  = (self.screen_height //2 ) - (self.height //2 )
        self.xcoordinate  = ( self.screen_width //2 )  -  (self.width //2 )
        self.dashboard.geometry(f"{self.width}x{self.height}+{10}+{20}")
    # Defining Constants 
        self.sidebar_maximized  =  True
    ## Defining the images and other visual parts 
        self.home_final_image  = ImageTk.PhotoImage(assets.home_resized)
        self.proile_image   = ImageTk.PhotoImage(assets.profile_image_resized)
        # self.bets_image  = ImageTk.PhotoImage(assets.bets_image_resized)
        
        
    # Defining the constants for the app system 
        self.options_box_opened  = False 
    ## Functions for the general work 
    def closing_app(self):
        self.dashboard.destroy()
    def mouse_move(self, event):
        self.x = event.x
        self.y = event.y
    def move_window(self , event):
        self.deltax = event.x - self.x
        self.deltay = event.y - self.y
        self.newx  = self.dashboard.winfo_x() + self.deltax
        self.newy = self.dashboard.winfo_y() + self.deltay
        self.dashboard.geometry(f"{self.width}x{self.height}+{self.newx}+{self.newy}")
    ## Functions for hovering Part
    def open_close_hover_enter(self, event):
        self.open_close_button.configure(background=colors.avatar_background)
    def open_close_hover_close(self, event):
        self.open_close_button.configure(background=colors.light_teal)
    def home_button_enter(self, event):
        self.dashboard_button.configure(background=colors.sky_blue , foreground=colors.black_color)
    def home_button_leave(self, enter):
        self.dashboard_button.configure(background=colors.light_teal , foreground=colors.white_backgrond)
    def settings_button_enter(self, event):
        self.settings_button.configure(background=colors.sky_blue , foreground=colors.black_color)
    def settings_button_leave(self, event):
        self.settings_button.configure(background=colors.light_teal , foreground=colors.white_backgrond)
    def history_button_enter(self, event):
        self.history_button.configure(background=colors.sky_blue , foreground=colors.black_color)
    def history_button_leave(self , event):
        self.history_button.configure(background=colors.light_teal , foreground=colors.white_backgrond)
    # Function to maximize and minimize the sidebar
    def maximizing_animation_sidebar(self , value):
        self.sidebar.config(width=value)
    
    def sidebar_max_min(self):
        if self.sidebar_maximized == False:
            self.sidebar.configure(width=150)
            self.sidebar_maximized = True
            self.open_close_button.place(x =111 , y = 0)
            self.dashboard_button.configure(width=16)
            self.settings_button.configure(width=16)
            self.history_button.config(width=16)
        elif self.sidebar_maximized == True:
            self.sidebar_maximized = False
            self.sidebar.configure(width=85)
            self.open_close_button.place(x=48 , y=0)
            self.dashboard_button.config(width=9)
            self.settings_button.config(width=9)
            self.history_button.config(width=9)

    
    ## Function to check and open the profile form
    def profile_form_called(self , event):
        
        if self.options_box_opened == False:
            self.options_box_opened = True
            xlocation  = self.profile_image_button.winfo_rootx() + 20
            ylocation = self.profile_image_button.winfo_rooty() + 35
            global hehe
            hehe = profile_data(xlocation , ylocation)
            hehe.controls()
        elif self.options_box_opened == True:
            self.options_box_opened = False
            hehe.close_application()
    

    def defining_controls(self):
    ## Defining frames - for the controls
        self.dashboard.configure(background=colors.white_backgrond)
        self.control_frame = tk.Frame(self.dashboard  , border=0  ,background=colors.dark_grey)
        self.control_frame.bind("<ButtonPress-1>" , self.mouse_move)
        self.control_frame.bind("<B1-Motion>" , self.move_window)
        self.control_button  = tk.Button(self.control_frame , text=" X " , foreground=colors.color_red , background=colors.dark_grey  , 
                                         relief=tk.GROOVE , border=0 , activebackground=colors.color_red ,activeforeground=colors.white_backgrond , command=self.closing_app)
        
        self.control_frame.propagate(1)

    ### Defining the sidebar from here 
        self.sidebar = tk.Frame(self.dashboard , background=colors.sky_blue, width=150 , height=676)
        self.sidebar.pack_propagate(0)

    #### Width 100 and height 676 would be chnaged in the main function and also
        self.open_close_button   =tk.Button(self.sidebar , text="+==+" , bd = 0 , activebackground=colors.sky_blue , activeforeground=colors.white_backgrond , foreground=colors.black_color , background=colors.light_teal , height=1 , command=self.sidebar_max_min)
        self.dashboard_button  = tk.Button(self.sidebar , text="Dashboard",font=fonts.large_font , background=colors.light_teal , activebackground=colors.some_dark_blue , relief=tk.GROOVE , bd=0 , foreground=colors.white_backgrond , height=1 , width=16
                                      ,activeforeground='white' , command='left')
        self.settings_button  =tk.Button(self.sidebar , text="Settings", font=fonts.large_font , background=colors.light_teal, activebackground=colors.some_dark_blue , relief=tk.SUNKEN , bd=0 , foreground=colors.white_backgrond , height=1 , width=16
                                      ,activeforeground='white')
        self.history_button = tk.Button(self.sidebar , text="History" , bd=0 , activebackground=colors.some_dark_blue , activeforeground=colors.white_backgrond , background=colors.light_teal
                                        ,relief=tk.SUNKEN , height=1 , width=16 , font=fonts.large_font , foreground=colors.white_backgrond)
        
        
    # self.dummy_button = tk.Button(self.sidebar , text= "Hello World" , compound="left" , image=self.home_final_image).place(x = 0 , y=400)

    ## First set controls for the user detils :
        self.upper_user_panel  =  tk.Frame(self.dashboard)
        self.middle_user_panel  = tk.Frame(self.dashboard)
        self.middle_graph_panel  = tk.Frame(self.dashboard)
        self.bottom_control_panel  = tk.Frame(self.dashboard)

    # Defining the profile pic and setting it as a control 
        self.profile_image_button  = tk.Label(self.dashboard , text="  User-Name" ,font=fonts.semi_large, image=self.proile_image , background=colors.white_backgrond , compound="left")
        self.profile_image_button.bind("<Button-1>" , self.profile_form_called)

    # Controls for the middle part 3 Boxes and their content: 
        self.total_balance_frame  = tk.Frame(self.dashboard  , width=250 , height=300 , background=colors.light_grey)
        self.total_balance_frame.pack_propagate(0)
        self.total_bets_frame  = tk.Frame(self.dashboard, width=250 , height=300 , background=colors.light_grey)
        self.total_bets_frame.pack_propagate(0)
        self.total_profit_frame  = tk.Frame(self.dashboard, width=250 , height=300 , background=colors.light_grey)
        self.total_profit_frame.pack_propagate(0)
    
    # Content for the 3 Boxes : 
        self.balance_text = Label(self.total_balance_frame , text="Total Balance" , font=fonts.super_large_font , background=colors.white_backgrond)
        self.bets_text = Label(self.total_bets_frame, text="Total Bets" , font=fonts.super_large_font , background=colors.white_backgrond)
        self.profit_text = Label(self.total_profit_frame , text="Total Profits" , font=fonts.super_large_font , background=colors.white_backgrond)

        ### Dummy button for the actual balance bets and other values
        self.actual_balance = Label(self.total_balance_frame , text="300" , font=fonts.super_large_font  , background=colors.white_backgrond)
        self.actual_bets = Label(self.total_bets_frame , text="50" , font=fonts.super_large_font , background=colors.white_backgrond)
        self.actual_profit   = Label(self.total_profit_frame , text="3333" , font=fonts.super_large_font , background=colors.white_backgrond)
        

    # Control  -  chart Frame
        self.chart_frame = tk.Frame(self.dashboard , height=200 , width=800 , background=colors.light_grey)

    # Bottom Frame for the trader controls :  
        self.bottom_frame = tk.Frame(self.dashboard , height=80 , width=800 , background=colors.light_grey)

    ## Contents for the three frames Defined 


    ### Binding buttons for the hovering part
        self.open_close_button.bind("<Enter>" , self.open_close_hover_enter)
        self.open_close_button.bind("<Leave>" , self.open_close_hover_close)
        self.dashboard_button.bind("<Enter>" , self.home_button_enter)
        self.dashboard_button.bind("<Leave>" , self.home_button_leave)
        self.settings_button.bind("<Enter>" , self.settings_button_enter)
        self.settings_button.bind("<Leave>" , self.settings_button_leave)
        self.history_button.bind("<Enter>" , self.history_button_enter)
        self.history_button.bind("<Leave>" , self.history_button_leave)


    def placing_controls(self):
    ## Base Controls that are to be placed at the top 
        self.control_frame.pack(side='top' , pady=0 , fill='x')
    # Packing the sidebar and its controls
        self.sidebar.place(x=0 , y=24)
        self.control_button.pack(side='right' , padx=0 , pady=1)
        self.open_close_button.place(x =111 , y = 0)
        self.dashboard_button.place(x=0,y=50)
        self.settings_button.place(x = 0 , y = 80)
        self.history_button.place(x = 0 , y=110)
        
    # Profile Button 
        self.profile_image_button.place(x = 870 , y=25)

    # Placing the middle controls : Frames and inner frames data
        self.total_balance_frame.place(x = 175 , y=85)
        self.total_bets_frame.place(x = 450 , y=85)
        self.total_profit_frame.place(x = 725 , y=85)

        self.balance_text.pack(side="top" , pady=40)
        self.bets_text.pack(side="top" ,pady=40)
        self.profit_text.pack(side="top" , pady=40)

        self.actual_balance.pack(pady=30)
        self.actual_bets.pack( pady=30)
        self.actual_profit.pack( pady=30)

    # Placing the chart controls
        self.chart_frame.place(x = 175 , y=400)

    # Placing the bottom controls
        self.bottom_frame.place(x = 175 , y=610)

    # Calling the main app
        self.dashboard.mainloop()




if __name__ == '__main__':
    hehe = Dashboard()
    hehe.defining_controls()
    hehe.placing_controls()

        
