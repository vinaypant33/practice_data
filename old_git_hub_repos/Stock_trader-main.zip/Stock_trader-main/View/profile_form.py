import tkinter as tk
from tkinter import messagebox
from PIL import ImageTk, Image
import colors
import assets
import fonts
from functools import partial



class profile_data():

    def __init__(self  , xlocation , ylocation) -> None:
        self.height = 95
        self.width = 100
        self.xloc = xlocation
        self.yloc = ylocation
        self.custom_messagebox  = tk.Tk()
        self.custom_messagebox.configure(background=colors.white_backgrond , border=1 , borderwidth=1 , highlightthickness=2)
        self.custom_messagebox.geometry(f"{self.width}x{self.height}+{self.xloc}+{self.yloc}")
        self.custom_messagebox.title("")
        self.custom_messagebox.overrideredirect(True)

        ## Settings the icons and resizing them for the form :
        self.home_icon = assets.home_image
        self.home_icon = self.home_icon.resize((12,12) , Image.LANCZOS)
        self.home_icon = ImageTk.PhotoImage(self.home_icon)

        self.history_icon  = assets.history_image
        self.history_icon = self.history_icon.resize((12,12), Image.LANCZOS)
        self.history_icon = ImageTk.PhotoImage(self.history_icon)

        self.settings_icon = assets.settings_image
        self.settings_icon = self.settings_icon.resize((12,12) , Image.LANCZOS)
        self.settings_icon = ImageTk.PhotoImage(self.settings_icon)

        self.power_icon = assets.power_image
        self.power_icon = self.power_icon.resize((12,12) , Image.LANCZOS)
        self.power_icon = ImageTk.PhotoImage(self.power_icon)


# Functions for the actions 
    def close_application(self):
        self.custom_messagebox.destroy()

    def close_button(self ,Event):
        self.custom_messagebox.destroy()

    def hover_enter_logout (self,event):
        self.logout_button_with_icon.configure(background=colors.light_teal  , foreground=colors.white_backgrond)

    def hover_leave_logout(self,event):
        self.logout_button_with_icon.configure(background=colors.white_backgrond , foreground=colors.black_color)

    def hover_dashboard_enter(self,event):
        self.dashboard_label.configure(background=colors.light_teal  , foreground=colors.white_backgrond)

    def hover_dashboard_leave(self, event):
        self.dashboard_label.configure(background=colors.white_backgrond , foreground=colors.black_color)

    def hover_history_enter(self,event):
        self.history_label.configure(background=colors.light_teal  , foreground=colors.white_backgrond)

    def hover_history_leave(self,event):
        self.history_label.configure(background=colors.white_backgrond , foreground=colors.black_color)

    def hover_settings_enter(self,event):
        self.settings_label.configure(background=colors.light_teal  , foreground=colors.white_backgrond)

    def hover_settings_leave(self, event):
        self.settings_label.configure(background=colors.white_backgrond , foreground=colors.black_color)


    def controls(self):
        self.dashboard_label  = tk.Label(self.custom_messagebox  ,text="Dashboard" ,font=fonts.medium_font)
        self.dashboard_label.configure(background=colors.white_backgrond)
        self.history_label  = tk.Label(self.custom_messagebox ,text="History", font=fonts.medium_font  , padx=30)
        self.history_label.configure(background=colors.white_backgrond)
        # self.settings_label = tk.Label(self.custom_messagebox , text="Settings" , image=self.settings_icon , compound="left" , font=fonts.medium_font , justify="left" , padx=25)
        self.settings_label = tk.Label(self.custom_messagebox , text="Settings" , font=fonts.medium_font , padx=25)
        self.settings_label.configure(background=colors.white_backgrond)
        self.middle_boder  = tk.Frame(self.custom_messagebox ,height=1 , background=colors.light_grey)
        self.logout_button_with_icon = tk.Label(self.custom_messagebox , text="Logout"  , font=fonts.medium_font , padx=37)
        self.logout_button_with_icon.bind("<Button-1>" , self.close_button)
        # self.logout_button_with_icon.bind("<Enter>" , partial(self.hover , self.logout_button_with_icon))
        self.logout_button_with_icon.configure(background=colors.white_backgrond)

        # Binding for the Hover Part
        self.logout_button_with_icon.bind("<Enter>" , self.hover_enter_logout)
        self.logout_button_with_icon.bind("<Leave>" , self.hover_leave_logout)
        self.dashboard_label.bind("<Enter>" , self.hover_dashboard_enter)
        self.dashboard_label.bind("<Leave>" , self.hover_dashboard_leave)
        self.history_label.bind("<Enter>" , self.hover_history_enter)
        self.history_label.bind("<Leave>" , self.hover_history_leave)
        self.settings_label.bind("<Enter>" , self.hover_settings_enter)
        self.settings_label.bind("<Leave>" , self.hover_settings_leave)


        self.dashboard_label.pack(fill="x")
        self.history_label.pack()
        self.settings_label.pack()
        self.middle_boder.pack(fill="x")
        self.logout_button_with_icon.pack()
        self.custom_messagebox.mainloop()



if __name__  == '__main__':
    hehe = profile_data(20,20)
    hehe.controls()
