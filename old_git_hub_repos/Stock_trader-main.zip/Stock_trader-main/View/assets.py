from PIL import Image, ImageTk




home_image  = Image.open("Assets\home.png")
home_resized  = home_image.resize((100,100) ,Image.LANCZOS)


profile_image  = Image.open("Assets\profilepic.png")
profile_image_resized = profile_image.resize((30,30) , Image.LANCZOS)

history_image  = Image.open("Assets\History.png")
history_reized  = history_image.resize((30, 30 ) , Image.LANCZOS)

settings_image  = Image.open("Assets\Settings.png")
settings_image = settings_image.resize((30,30) , Image.LANCZOS)

power_image  = Image.open("Assets\power.png")



# bets_image  = Image.open("Assets\namebet.png")
# bets_image_resized  = bets_image.resize((50,50) , Image.LANCZOS)
# money_image  = "Assets\money.png"
