# Defining Colors for the main app  

dark_grey  = '#040F16' # Will be used for the headings and button backgrounds so some ncie animation 
light_teal = '#005E7C' # Will be used for some foreground and some form borders  for some clicks
sky_blue  = '#0094C6' # Admin name and other dashboard parts some message info also 
some_dark_blue  = '#001242' # Final Coloring and animation total addition by 15%  
dark_blue  = '#000022' #  Final usage for less than 10% in simple animation and hover effect only  

white_backgrond  =  'white'
black_color = 'black'

color_red = 'red'
avatar_background  = '#F0F0F0'

light_grey = "#D3D3D3"