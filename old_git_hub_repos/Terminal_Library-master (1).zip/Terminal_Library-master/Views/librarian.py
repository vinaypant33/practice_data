from tkinter import *







class Librarian():


    def __init__(self) -> None:
        pass


    