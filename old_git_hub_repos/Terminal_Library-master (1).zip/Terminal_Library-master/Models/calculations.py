import datetime

## Function to send the book names which are taken by the username
def book_taken_data(book_list):
    book_taken_names  = []
    for books in book_list:
        book_taken_names.append(books[0])
    return book_taken_names
    
""" Not in use"""
# ## Fuction to send the book which can be taken
# def book_to_take_data(book_list):
#     book_to_take_names = []
#     for books in book_list:
#         book_to_take_names.append(books[0])
#     return book_to_take_names



## Funcion to check the diff bw two dates and add them as the int

def date_diff():
    pass
