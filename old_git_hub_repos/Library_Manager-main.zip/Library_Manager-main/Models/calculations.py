""" Will only be used for the price calculation and won't access the database directly """
# Importing the files for further working 

import sqlite3
import time


# Function the get the details and share the list of the final calculation
