from datetime import datetime
from flask_bcrypt import Bcrypt
from flask import Flask, render_template, url_for, flash, redirect
from flask_sqlalchemy import SQLAlchemy
from flask_login import login_manager
from forms import RegistrationForm, LoginForm

app = Flask(__name__)

app.config['SECRET_KEY'] = '1221wesd3234erdf'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'


db = SQLAlchemy(app)
bcrypt = Bcrypt(app)



class User(db.Model):
    id = db.Column(db.Integer, primary_key  = True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    image_File = db.Column(db.String(20), unique=False, nullable=False, default='default.jpg')
    password = db.Column(db.String(60), nullable=False)
    posts = db.relationship('Post', backref='author', lazy=True)



    def __repr__(self):
        return "user('{self.usernmae}'"

class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    date_posted = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    content = db.Column(db.Text, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)


    def __repr__(self):
        return Post({'self.title' , '{self.date_posted', '{self.image_file}'})




posts  = [
    {
        'author' : 'vinay',
        'title' : 'titlename'
    } ,

    {
        'author' : 'himanshu' ,
        'title' : 'title2'
    }
]

title = "About page title made  in python"


@app.route('/')
def hello_world():

    return  render_template('main.html', posts=posts)

@app.route('/Settings')
def settings():
    return render_template('about.html', title = title)

@app.route('/Register', methods = ['GET', 'POST'])
def registration():
    form = RegistrationForm()
    if form.validate_on_submit():
        #hashed_password = bcrypt.generate_password_hash((form.password.data).decode('utf-8'))
        user = User(username = form.username.data, email = form.email.data, password =form.password.data)
        db.session.add(user)
        db.session.commit()
        flash("Accopunt Created")
        return redirect(url_for('login'))
    return render_template('register.html', title ='register', form = form)

@app.route('/Login', methods = ['GET', 'POST'])
def login():
  return render_template('login.html')



if __name__ == '__main__':
    app.run(debug=True)
