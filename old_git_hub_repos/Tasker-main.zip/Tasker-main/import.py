from flask_bcrypt import Bcrypt 
bcrypt = Bcrypt()
hashed = bcrypt.generate_password_hash('VINAY')
print(bcrypt.generate_password_hash('VINAY'))
print(bcrypt.generate_password_hash('VINAY').decode('utf-8'))
print(bcrypt.check_password_hash(hashed , 'VINAY'))
