function hidelogin(){
    document.getElementById('logindiv').style.display = "none";
    document.getElementById('registerdiv').style.display = "block";

}


function hideregister(){
 document.getElementById('registerdiv').style.display = "block";
 document.getElementById('logindiv').style.display = "none";

}
