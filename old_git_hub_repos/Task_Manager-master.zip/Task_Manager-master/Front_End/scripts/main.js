// document.getElementById('clickme2').onclick = function(){
//     eel.maindata("Calling from JS and getting the data soon")(function(ret){alert(ret)})
// }

// File responsible for the sub function running on the main page. 


canvas = document.getElementById('canvas_div')
canvas.onload = function(){
    alert("i am loaded");
}