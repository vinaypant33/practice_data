﻿using LiveCharts;
using LiveCharts.Defaults; // Needed for ObservableValue
using LiveCharts.Wpf;
using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Media; // Needed for SolidColorBrush, LinearGradientBrush

namespace FitnessDashboard
{
    public class DashboardViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        // --- Overview Chart Properties ---
        private SeriesCollection _overviewSeriesCollection;
        public SeriesCollection OverviewSeriesCollection
        {
            get => _overviewSeriesCollection;
            set { _overviewSeriesCollection = value; OnPropertyChanged(); }
        }

        private string[] _overviewLabels;
        public string[] OverviewLabels
        {
            get => _overviewLabels;
            set { _overviewLabels = value; OnPropertyChanged(); }
        }

        public Func<double, string> OverviewFormatter { get; set; }

        // --- Weekly Weight Chart Properties ---
        private SeriesCollection _weightSeriesCollection;
        public SeriesCollection WeightSeriesCollection
        {
            get => _weightSeriesCollection;
            set { _weightSeriesCollection = value; OnPropertyChanged(); }
        }

        private string[] _weightLabels;
        public string[] WeightLabels
        {
            get => _weightLabels;
            set { _weightLabels = value; OnPropertyChanged(); }
        }

        public Func<double, string> WeightFormatter { get; set; }

        // --- Calories Burned Chart Properties ---
        private SeriesCollection _caloriesSeriesCollection;
        public SeriesCollection CaloriesSeriesCollection
        {
            get => _caloriesSeriesCollection;
            set { _caloriesSeriesCollection = value; OnPropertyChanged(); }
        }

        public Func<ChartPoint, string> CaloriesPointLabel { get; set; }


        // --- Daily Activity Duration Chart Properties ---
        private SeriesCollection _activityDurationSeriesCollection;
        public SeriesCollection ActivityDurationSeriesCollection
        {
            get => _activityDurationSeriesCollection;
            set { _activityDurationSeriesCollection = value; OnPropertyChanged(); }
        }

        private string[] _activityDurationLabels;
        public string[] ActivityDurationLabels
        {
            get => _activityDurationLabels;
            set { _activityDurationLabels = value; OnPropertyChanged(); }
        }


        // --- Constructor ---
        public DashboardViewModel()
        {
            InitializeOverviewChart();
            InitializeWeightChart();
            InitializeCaloriesChart();
            InitializeActivityDurationChart();
        }

        // --- Initialization Methods for Charts ---
        private void InitializeOverviewChart()
        {
            OverviewSeriesCollection = new SeriesCollection
            {
                new LineSeries
                {
                    Title = "Activity",
                    Values = new ChartValues<double> { 5, 8, 6, 10, 7, 9, 12, 11, 13, 10, 8, 15 },
                    PointGeometrySize = 10,
                    Fill = new LinearGradientBrush
                    {
                        GradientStops = new GradientStopCollection
                        {
                            new GradientStop(Color.FromArgb(50, 106, 27, 154), 0), // Purple with transparency
                            new GradientStop(Colors.Transparent, 1)
                        },
                        StartPoint = new Point(0, 0),
                        EndPoint = new Point(0, 1)
                    },
                    Stroke = new SolidColorBrush(Color.FromRgb(106, 27, 154)) // Purple line
                }
            };
            OverviewLabels = new[] { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
            OverviewFormatter = value => value.ToString("N0");
        }

        private void InitializeWeightChart()
        {
            WeightSeriesCollection = new SeriesCollection
            {
                new LineSeries
                {
                    Title = "Weight",
                    Values = new ChartValues<ObservableValue> // Using ObservableValue for potential live updates
                    {
                        new ObservableValue(75.2), // Day 1
                        new ObservableValue(75.0),
                        new ObservableValue(74.8),
                        new ObservableValue(74.9),
                        new ObservableValue(74.5),
                        new ObservableValue(74.6),
                        new ObservableValue(74.2)  // Day 7
                    },
                    PointGeometrySize = 8,
                    Stroke = new SolidColorBrush(Color.FromRgb(33, 150, 243)), // Blue line
                    Fill = new LinearGradientBrush
                    {
                        GradientStops = new GradientStopCollection
                        {
                            new GradientStop(Color.FromArgb(30, 33, 150, 243), 0),
                            new GradientStop(Colors.Transparent, 1)
                        },
                        StartPoint = new Point(0, 0),
                        EndPoint = new Point(0, 1)
                    }
                }
            };
            WeightLabels = new[] { "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun" };
            WeightFormatter = value => value.ToString("N1");
        }

        private void InitializeCaloriesChart()
        {
            CaloriesPointLabel = chartPoint =>
                string.Format("{0} ({1:P1})", chartPoint.SeriesView.Title, chartPoint.Participation);

            CaloriesSeriesCollection = new SeriesCollection
            {
                new PieSeries
                {
                    Title = "Jogging",
                    Values = new ChartValues<double> { 1200 },
                    DataLabels = true,
                    LabelPoint = CaloriesPointLabel,
                    Fill = new SolidColorBrush(Color.FromRgb(106, 27, 154)) // Purple
                },
                new PieSeries
                {
                    Title = "Cycling",
                    Values = new ChartValues<double> { 800 },
                    DataLabels = true,
                    LabelPoint = CaloriesPointLabel,
                    Fill = new SolidColorBrush(Color.FromRgb(255, 111, 97)) // Orange/Red
                },
                new PieSeries
                {
                    Title = "Walking",
                    Values = new ChartValues<double> { 500 },
                    DataLabels = true,
                    LabelPoint = CaloriesPointLabel,
                    Fill = new SolidColorBrush(Color.FromRgb(50, 205, 50)) // Green
                },
                new PieSeries
                {
                    Title = "Other",
                    Values = new ChartValues<double> { 300 },
                    DataLabels = true,
                    LabelPoint = CaloriesPointLabel,
                    Fill = new SolidColorBrush(Color.FromRgb(128, 128, 128)) // Grey
                }
            };
        }

        private void InitializeActivityDurationChart()
        {
            ActivityDurationSeriesCollection = new SeriesCollection
            {
                new ColumnSeries
                {
                    Title = "Duration",
                    Values = new ChartValues<double> { 60, 45, 30, 90 }, // Example durations for Jogging, Cycling, Walking, Gym
                    Fill = new SolidColorBrush(Color.FromRgb(60, 179, 113)) // Medium Sea Green
                }
            };
            ActivityDurationLabels = new[] { "Jogging", "Cycling", "Walking", "Gym" };
        }
    }
}
